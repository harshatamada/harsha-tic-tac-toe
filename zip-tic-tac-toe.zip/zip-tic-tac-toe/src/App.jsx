import Player from "./assets/components/Player";

function App() {
  return (
    <header>
      <img src="game-logo.png" alt="tic-toc-toe" />
      <h1>Tic-Tac-Toe</h1>
      <main>
        <div id="game-container">
          <ol id="players">
            <Player name="player 1" symbol="X" />
            <Player name="player 2" symbol="O" />
          </ol>
          GAme board
        </div>
      </main>
    </header>
  );
}

export default App;
